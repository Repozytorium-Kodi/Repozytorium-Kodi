# -*- coding: UTF-8 -*-

from resources.lib.orange import OrangeGo

if __name__ == '__main__':
    OrangeGo()