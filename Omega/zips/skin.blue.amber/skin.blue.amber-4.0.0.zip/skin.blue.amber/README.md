skin.blue.amber
===============

Amber skin for Kodi v21 Omega. Blue MOD.
