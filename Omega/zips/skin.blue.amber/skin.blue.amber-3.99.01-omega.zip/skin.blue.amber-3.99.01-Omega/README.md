## Amber skin for Kodi - blue MOD
[![Generic badge](https://img.shields.io/badge/Platform-KODI-<COLOR>.svg)](https://kodi.tv/) 
[![GitHub release (latest by date)](https://img.shields.io/github/v/release/zuzia-dev/skin.blue.amber?color=orange)](https://github.com/zuzia-dev/skin.blue.amber/releases/latest)
![GitHub latest commit](https://img.shields.io/github/last-commit/zuzia-dev/skin.blue.amber?color=00BFFF)

> Master branch: Kodi Omega. Nexus branch: Kodi Nexus.
### Installation & Updates
> ###### Provide automatic installation of updates - download repository: [Repozytorium-Kodi](https://repozytorium-kodi.github.io/Repozytorium-Kodi.zip).
> ###### Or via Kodi's file-manager, add source: https://repozytorium-kodi.github.io


<img src="https://raw.githubusercontent.com/zuzia-dev/skin.blue.amber/7607db3694caba0ecddaa499f6d181bdc98e30ce/resources/screenshot01.jpg?raw=true" width="600" />

<img src="https://raw.githubusercontent.com/zuzia-dev/skin.blue.amber/7607db3694caba0ecddaa499f6d181bdc98e30ce/resources/screenshot08.jpg?raw=true" width="600" />

<img src="https://raw.githubusercontent.com/zuzia-dev/skin.blue.amber/7607db3694caba0ecddaa499f6d181bdc98e30ce/resources/screenshot06.jpg?raw=true" width="600" />

